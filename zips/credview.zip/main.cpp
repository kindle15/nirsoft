#include <windows.h>
#include <stdio.h>
#include "credcls.h"

/*
CredView Sample.
Written by Nir Sofer.
http://www.nirsoft.net

This sample code enumerates all credentials of the current logged on user,
and dump them into the standard output.  
Works only under Windows XP and Windows 2003 Server.

*/

int wmain( int argc, wchar_t *argv[])
{
	CWinCredentials WinCredentials;

	//Load Credentials API functions.
	if (WinCredentials.LoadCredsLibrary())
	{

		PCREDENTIAL *pCredArray = NULL;
		DWORD dwCount = 0;

		//Load all credentials into array.
		if (WinCredentials.CredEnumerate(NULL, 0, &dwCount, &pCredArray))
		{

			for (DWORD dwIndex = 0; dwIndex < dwCount; dwIndex++)
			{
				PCREDENTIAL pCredential = pCredArray[dwIndex];

				//Write the Credential information into the standard output.
				printf("*********************************************\r\n");
				printf(	"Flags:   %d\r\n"\
						"Type:    %d\r\n"\
						"Name:    %ls\r\n"\
						"Comment: %ls\r\n"\
						"Persist: %d\r\n"\
						"User:    %ls\r\n",
						pCredential->Flags,
						pCredential->Type,
						pCredential->TargetName, 
						pCredential->Comment,
						pCredential->Persist,
						pCredential->UserName);

				
				printf( "Data: \r\n");

				char szHexBuffer[256] = "";
				char szAsciiBuffer[256] = "";
				char szHex[16];
				char szAscii[2];
				DWORD dwByte;

				//Write the credential's data as Hex Dump.
				for (dwByte = 0; dwByte < pCredential->CredentialBlobSize; dwByte++)
				{
					BYTE byte1 = pCredential->CredentialBlob[dwByte];
					sprintf(szHex, "%2.2X ", byte1);
					szAscii[1] = '\0';

					if (byte1 >= 32 && byte1 < 128)
						szAscii[0] = (UCHAR)byte1;
					else
						szAscii[0] = ' ';

					strcat(szHexBuffer, szHex);
					strcat(szAsciiBuffer, szAscii);

					if (dwByte == pCredential->CredentialBlobSize - 1 
						|| dwByte % 16 == 15)
					{
						printf("%-50s %s\r\n", szHexBuffer, szAsciiBuffer);
						szHexBuffer[0] = '\0';
						szAsciiBuffer[0] = '\0';
					}


				}

				printf("*********************************************\r\n");
				printf("\r\n\r\n");

			}

			//Free the credentials array.
			WinCredentials.CredFree(pCredArray);
		}
		
	}
	else
	{

		printf("Failed to load the Credentials API functions !\r\n");
	}

	return 0;
}


