#ifndef _CREDCLS_H_
#define _CREDCLS_H_
#include <wincred.h>

/*
CWinCredentials Class
Written by Nir Sofer.
http://www.nirsoft.net

This small class encapsulates the calls to CredRead, CredEnumerate, CredFree
API functions. These functions are only available under Windows XP and
Windows 2003 Server.
 
*/


class CWinCredentials
{
protected:

	typedef BOOL (WINAPI *CredReadFuncType)(
		LPCTSTR TargetName, 
		DWORD Type, 
		DWORD Flags, 
		PCREDENTIAL *Credential
		);

	typedef BOOL (WINAPI *CredEnumerateType)(
		LPCTSTR Filter, 
		DWORD Flags, 
		DWORD *Count, 
		PCREDENTIAL **Credentials
		);

	typedef VOID (WINAPI *CredFreeFuncType)(PVOID Buffer);

	
	HMODULE hAdvApi32;
	BOOL bLoaded;
	CredReadFuncType pCredRead;
	CredFreeFuncType pCredFree;
	CredEnumerateType pCredEnumerate;

public:
	CWinCredentials();
	~CWinCredentials();
	BOOL LoadCredsLibrary();
	void FreeCredsLibrary();
	BOOL IsLoaded();
	BOOL CredRead(
		LPCTSTR TargetName, 
		DWORD Type, 
		DWORD Flags, 
		PCREDENTIAL *Credential
		);

	BOOL CredEnumerate(
		LPCTSTR Filter, 
		DWORD Flags, 
		DWORD *Count, 
		PCREDENTIAL **Credentials
		);

	VOID CredFree(PVOID Buffer);
};

#endif