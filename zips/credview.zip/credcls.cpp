#include <windows.h>
#include <TCHAR.H>
#include "credcls.h"

/*
CWinCredentials Class
Written by Nir Sofer.
http://www.nirsoft.net

This small class encapsulates the calls to CredRead, CredEnumerate, CredFree
API functions. These functions are only available under Windows XP and
Windows 2003 Server.
 
*/

CWinCredentials::CWinCredentials()
{
	hAdvApi32 = NULL;
	bLoaded = FALSE;
}

CWinCredentials::~CWinCredentials()
{
	FreeCredsLibrary();
}

BOOL CWinCredentials::IsLoaded()
{
	return bLoaded;
}


BOOL CWinCredentials::LoadCredsLibrary()
{
	if (bLoaded) return TRUE;

	hAdvApi32 = LoadLibrary(_T("advapi32.dll"));
	if (hAdvApi32 != NULL)
	{
		//Dynamically load CredRead, CredEnumerate, and CredFree API functions.
		pCredRead = (CredReadFuncType)GetProcAddress(hAdvApi32, "CredReadW");
		pCredFree = (CredFreeFuncType)GetProcAddress(hAdvApi32, "CredFree");
		pCredEnumerate = (CredEnumerateType)GetProcAddress(hAdvApi32, "CredEnumerateW");

		//If all 3 functions are available, return TRUE.
		if (pCredRead != NULL && pCredFree != NULL && pCredEnumerate != NULL)
			bLoaded = TRUE;
		else
		{
			//Failed to load the credentials API functions.
			FreeCredsLibrary();
		}
	}

	return bLoaded;
}

void CWinCredentials::FreeCredsLibrary()
{
	//Free advapi32 library, if we previously loaded it.
	if (hAdvApi32 != NULL)
	{
		FreeLibrary(hAdvApi32);
		hAdvApi32 = NULL;
	}

	bLoaded = FALSE;

}


BOOL CWinCredentials::CredRead(
	LPCTSTR TargetName, 
	DWORD Type, 
	DWORD Flags, 
	PCREDENTIAL *Credential
	)
{
	if (bLoaded)
		return pCredRead(TargetName, Type, Flags, Credential);
	else
		return FALSE;
}


BOOL CWinCredentials::CredEnumerate(
	LPCTSTR Filter, 
	DWORD Flags, 
	DWORD *Count, 
	PCREDENTIAL **Credentials
	)
{
	if (bLoaded)
		return pCredEnumerate(Filter, Flags, Count, Credentials);
	else
		return FALSE;
}

VOID CWinCredentials::CredFree(PVOID Buffer)
{
	if (bLoaded)
		pCredFree(Buffer);
}
