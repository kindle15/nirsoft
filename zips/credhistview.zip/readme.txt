


CredHistView v1.01
Copyright (c) 2020 - 2023 Nir Sofer
Web site: https://www.nirsoft.net/utils/credhist_view.html



Description
===========

Every time that you change the login password on your system, Windows
stores the hashes of the previous password in the CREDHIST file (Located
in %appdata%\Microsoft\Protect\CREDHIST ) This tool allows you to decrypt
the CREDHIST file and view the SHA1 and NTLM hashes of all previous
passwords you used on your system. In order to decrypt the file, you have
to provide your latest login password. You can this tool to decrypt the
CREDHIST file on your currently running system, as well as to decrypt the
CREDHIST stored on external hard drive.



System Requirements
===================

This tool works on any version of Windows, starting from Windows XP and
up to Windows 11. Both 32-bit and 64-bit systems are supported.



Version History
===============


* Version 1.01:
  o Fixed a problem with decrypting the CREDHIST file on Windows 11
    22H2.

* Version 1.00 - First release.



How to use CredHistView
=======================

CredHistView doesn't require any installation process or additional DLL
files. In order to start using it, simply run the executable file -
CredHistView.exe
After running CredHistView, the options window is displayed, and you have
to provide the path of the CREDHIST filename you want to decrypt (e.g:
C:\Users\USer01\AppData\Roaming\Microsoft\Protect\CREDHIST ) and the last
login password (or the SHA1 hash of this password) of the user.
If you login with Microsoft account, you have to extract the encryption
password with the MadPassExt tool and then use it instead of the login
password.

After typing the needed information, press the Ok button, and the
information from the decrypted CREDHIST file will be displayed in the
main window of CredHistView.



What you can do with this tool
==============================

If you have an old copy of DPAPI-encrypted data originally encrypted with
your previous login passwords, you can use the SHA1 hash extracted with
this tool to decrypt the old DPAPI data. Most NirSoft tools that decrypt
DPAPI information (For example: DataProtectionDecryptor,
OutlookAccountsView, ChromeCookiesView, ExtPassword! ) can accept the
SHA1 hash of the password instead of the actual login password.



Translating CredHistView to other languages
===========================================

In order to translate CredHistView to other language, follow the
instructions below:
1. Run CredHistView with /savelangfile parameter:
   CredHistView.exe /savelangfile
   A file named CredHistView_lng.ini will be created in the folder of
   CredHistView utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run CredHistView, and all
   translated strings will be loaded from the language file.
   If you want to run CredHistView without the translation, simply rename
   the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
