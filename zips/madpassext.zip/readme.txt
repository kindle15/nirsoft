


MadPassExt v1.00 (Microsoft Account DPAPI Password Extractor)
Copyright (c) 2021 Nir Sofer
Web site:
https://www.nirsoft.net/utils/microsoft_account_dpapi_password.html



Description
===========

This tool allows you to decrypt and extract the secret DPAPI password
generated for your Microsoft account when using it to log into Windows 10
or Windows 11. After you retrieve this DPAPI password, you can use it to
recover passwords encrypted with DPAPI from external hard drive, as long
as they were encrypted with the same Microsoft account.

Example for NirSoft tools that allows you to recover passwords and data
from external drive with the password you extract with this tool:
* ChromeCookiesView - For extracting cookies of Chrome Web browser
  stored on external drive.
* ChromePass - For recovering passwords of Chrome Web browser stored on
  external drive.
* CredentialsFileView - For decrypting Windows Credentials passwords
  and data stored on external drive.
* VaultPasswordView - For decrypting Windows Vault passwords and data
  stored on external drive.



System Requirements
===================

You can use this tool on any version of Windows, as long as you know the
login password of your Microsoft account, and you have read access to the
cache file of your Microsoft account (Usually located under the following
folder -
C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Cl
oudAPCache\MicrosoftAccount )
Be aware that this cache file is generated only after you login with your
Microsoft account on Windows 10 or Windows 11.



How to use MadPassExt
=====================

MadPassExt doesn't require any installation process or additional DLL
files. In order to start using it, simply run the executable file -
MadPassExt.exe

After running MadPassExt.exe, the main window is displayed, and you have
to type the password of your Microsoft account. Optionally, you can also
type the filename or folder of your Microsoft account cache file. You can
find it in the following path:
C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Cl
oudAPCache\MicrosoftAccount\[Account ID]\Cache\CacheData
If you don't fill this field, MadPassExt will find the cache file of your
account automatically.

Click the 'Decrypt Microsoft Account Cache File' button to decrypt the
cache file. If you get 'Cannot find the cache file of your Microsoft
account' error message, you have to run this tool as Administrator ('Run
As Administrator' button) in order to get permission to read the
Microsoft account cache file. Alternatively, if you want to run this tool
without admin access - you can browse into the Microsoft account cache
folder from Windows Explorer, and then Windows Explorer will allow you to
add permission to this folder.

If you provided the correct password and MadPassExt managed to decrypt
the cache file, you should see the secret DPAPI password. You can click
the 'Copy DPAPI Password To Clipboard' button and then paste it to the
login password field of another tool that decrypts the DPAPI passwords.



Translating MadPassExt to other languages
=========================================

In order to translate MadPassExt to other language, follow the
instructions below:
1. Run MadPassExt with /savelangfile parameter:
   MadPassExt.exe /savelangfile
   A file named MadPassExt_lng.ini will be created in the folder of
   MadPassExt utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run MadPassExt, and all
   translated strings will be loaded from the language file.
   If you want to run MadPassExt without the translation, simply rename
   the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
