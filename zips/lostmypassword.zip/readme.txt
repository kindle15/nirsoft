


LostMyPassword v1.02
Copyright (c) 2020 - 2025 Nir Sofer
Web site: https://www.nirsoft.net/utils/lost_my_password.html



Description
===========

LostMyPassword is a tool for Windows that allows you to recover a lost
password, if it's stored by a software installed on your system.
LostMyPassword can extract the passwords from popular programs, including
Web browsers (Chrome, Firefox, Microsoft Edge, Brave, Internet Explorer,
Opera, and more...), POP3/IMAP/SMTP passwords stored by email software
(Microsoft Outlook, Thunderbird, Windows Mail), Dialup/VPN passwords
stored by Windows operating system, login passwords of remote computer
stored by Windows operating system. You can use the LostMyPassword tool
in 2 modes: as normal user, and as Administrator. The Administrator mode
is needed for some types of passwords because they cannot be decrypted
without Administrator privileges. If you have 64-bit system, you should
use the 64-bit version of LostMyPassword to ensure that you get all
passwords stored on your system.



System Requirements
===================

This tool works on any version of Windows, starting from Windows XP and
up to Windows 11. Both 32-bit and 64-bit systems are supported. In order
to retrieve all types of passwords on 64-bit system, you have to use the
64-bit version of LostMyPassword.
Notice: On the latest update of Windows 11 (24H2), LSA protection is
enabled by default, and this feature blocks LostMyPassword from
retrieving passwords stored by Windows operating system. You can disable
the LSA protection by following the instructions on this Microsoft Web
page: Disable LSA protection



Versions History
================


* Version 1.02:
  o Updated to decrypt the passwords for the encryption change of
    Firefox 144 and Thunderbird 146.

* Version 1.01:
  o Updated to decrypt the passwords encrypted with app-bound
    encryption on new versions of Chrome (Third version of the app-bound
    encryption key).

* Version 1.00 - First release.



Start Using LostMyPassword
==========================

LostMyPassword doesn't require any installation process or additional DLL
files. In order to start using it, simply run the executable file -
LostMyPassword.exe
After you run LostMyPassword, you have to choose the desired mode to use
the LostMyPassword tool: as normal user or as Administrator. You can
start LostMyPassword as normal user and then if you don't find the
desired password, Press Ctrl+F11 (Help -> Run As Administrator) to run
LostMyPassword as Administrator.



Translating LostMyPassword to other languages
=============================================

In order to translate LostMyPassword to other language, follow the
instructions below:
1. Run LostMyPassword with /savelangfile parameter:
   LostMyPassword.exe /savelangfile
   A file named LostMyPassword_lng.ini will be created in the folder of
   LostMyPassword utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run LostMyPassword, and all
   translated strings will be loaded from the language file.
   If you want to run LostMyPassword without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
