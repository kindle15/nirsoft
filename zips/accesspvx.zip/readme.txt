====================================

Access PassView ActiveX DLL v1.00
Copyright (c) 2002 Nir Sofer

Web site: http://nirsoft.cjb.net
====================================


Description
===========
The Access PassView ActiveX is a small ActiveX component that allows you to retrieve
the database password of every password-protected mdb file that created with Microsoft Access 95/97/2000/XP or with Jet Database Engine 3.0/4.0 .
You can use this component in all development tools that supports ActiveX components, 
including Visual Basic, Visual C++, Microsoft Access, Delphi, and other development tools...
 

Known Limitations
=================
* Passwords of Access 2000/XP files cannot be recovered if their length is longer than 18 characters.
* This ActiveX DLL can only reveal the main database password. It cannot recover the user-level passwords.


License
=======
This ActiveX DLL is released as freeware. You can freely use and distribute it.
If you distribute this component, you must include all files in the distribution package including the readme.txt, without any modification !


Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed or implied,
including, but not limited to, the implied warranties of merchantability and fitness
for a particular purpose. The author will not be liable for any special, incidental,
consequential or indirect damages due to loss of data or any other reason. 


Installing the Access PassView ActiveX DLL
==========================================
The Access PassView ActiveX package doesn't provide any installation program, but
you can easily install it by yourself.

This DLL was developed in Visual C++ with MFC, and requires the following DLL files:
* msvcrt.dll, version 6.00.xxxx or later
* mfc42.dll, version 6.00.xxxx or later 

The above files are usually installed with your operating system, Visual Basic, 
Microsoft Office, and with other Microsoft products, so in most cases, you don't have 
to install them by yourself. 
If you don't have the above MFC files in your system, You can download and install
them from Microsoft Web site at http://activex.microsoft.com/controls/vc/mfc42.cab

In order to start using this ActiveX DLL, you have to register it on your machine.
You can use the regsvr32 utility for registering the Access PassView ActiveX component.
In order to do it, type the following command:
regsvr32 accesspv.dll


Using the Access PassView ActiveX DLL
==========================================
The Access PassView ActiveX is a very simple ActiveX component containing only one method, in one class.
In order to use it, follow the instructions below:

1. Create an object from the NirSoft.AccessPassView class.
   Set Obj = CreateObject("NirSoft.AccessPassView")  
	
2. Call the GetPassword method for getting the database password of your mdb file.
   strPassword = Obj.GetPassword(strMDBFilename)

The Access PassView ActiveX package includes a Visual Basic sample that demonstrates how 
to use this component. You can watch it by opening the accesspv.vbp project.


Feedback
========
If you have any problem, suggestion, comment, or you found a bug in my dll, you can 
send a message to nirsofer@yahoo.com

