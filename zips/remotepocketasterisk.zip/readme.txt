


RemotePocketAsterisk v1.00
Copyright (c) 2007 Nir Sofer
Web site: http://www.nirsoft.net



Description
===========

RemotePocketAsterisk is a small utility that reveals that passwords
stored behind the asterisks ('***') in standard password text-boxes of
Pocket PC. This utility doesn't install anything on the Pocket PC device,
but instead it simply grab the asterisk passwords though the ActiveSync
connection.



System Requirements
===================


* Windows 2000/XP/2003/Vista with Microsoft ActiveSync Software.
* Pocket PC device - connected to the ActiveSync Software.



Using RemotePocketAsterisk
==========================

RemotePocketAsterisk doesn't require any installation process or
additional DLL files. In order to use it, follow the instructions below:
1. In your Pocket PC device, open the application that contains the
   asterisk password you want to recover. In our example, it's a POP3
   account of the 'Messaging' program:



2. Connect the Pocket PC device to your desktop computer.
3. Run the executable file of RemotePocketAsterisk
   (RemotePocketAsterisk.exe). Wait a few seconds. If everything works
   fine, you should see the password in the main window of
   RemotePocketAsterisk:






License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
